-- creare il database da utilizzare
-- create database ToysGroup_sales_2020_2023
-- impostarlo come DB da usare
-- use ToysGroup_sales_2020_2023


-- creazione delle tabelle (ho creato anche la tabella categorie giochi per seguire la regola di normalizzazione)
-- le vendite non hanno un campo quantità perché la traccia diceva che ciascuna transazione fosse riferita a un solo prodotto
CREATE TABLE Toy_category (
    Category_ID INT PRIMARY KEY,
    Category_name VARCHAR(20)
);

CREATE TABLE Toy (
    Toy_ID INT PRIMARY KEY,
    Toy_name VARCHAR(30),
    Toy_price DECIMAL(5 , 2 ),
    Category_ID INT,
    FOREIGN KEY (Category_ID)
        REFERENCES Toy_category (Category_ID)
);

CREATE TABLE Sales_Region (
    Region_ID INT PRIMARY KEY,
    Region_name VARCHAR(25)
);

CREATE TABLE Sales (
    Transaction_ID INT PRIMARY KEY,
    Toy_ID INT,
    Transaction_date DATE,
    Region_ID INT,
    FOREIGN KEY (Toy_ID)
        REFERENCES Toy (Toy_ID),
    FOREIGN KEY (Region_ID)
        REFERENCES Sales_Region (Region_ID)
);

-- popolamento tabella categorie giochi
INSERT INTO Toy_Category (Category_ID, Category_name) VALUES
(1,'Educational Toys'),
(2,'Action Toys'),
(3,'Creative Toys'),
(4,'Role-Playing Toys');

-- popolamento tabella dei giochi
INSERT INTO Toy (Toy_ID, Toy_name, Toy_price, Category_ID) VALUES
(1, 'LEGO Mindstorms', 129.99, 1),
(2, 'Alphabet Blocks', 25.50, 1),
(3, 'Science Lab Kit', 45.00, 1),
(4, 'Memory Game', 20.00, 1),
(5, 'Superhero Action Figure', 30.00, 2),
(6, 'Remote Control Car', 55.99, 2),
(7, 'Nerf Blaster', 35.00, 2),
(8, 'Drone with Camera', 120.00, 2),
(9, 'Painting Set', 40.00, 3),
(10, 'Bead Craft Kit', 22.50, 3),
(11, 'Mini Piano', 75.00, 3),
(12, 'Knitting Kit', 28.00, 3),
(13, 'Dollhouse', 85.00, 4),
(14, 'Toy Kitchen Set', 50.00, 4),
(15, 'Doctor Kit', 32.99, 4),
(16, 'Costume Set', 40.00, 4),
(17, 'Robot Building Kit', 99.99, 1),
(18, 'Toy Truck Set', 25.00, 2),
(19, 'Clay Modeling Set', 20.50, 3),
(20, 'Vet Play Set', 27.00, 4);

-- popolamento tabella regioni di vendita
insert into Sales_region (Region_ID, Region_name) values
(1, 'Germany'),
(2, 'France'),
(3, 'Italy'),
(4, 'Spain'),
(5, 'United Kingdom'),
(6, 'United States'),
(7, 'Canada'),
(8, 'Mexico'),
(9, 'China'),
(10, 'Japan');

-- popolamento tabella transazioni
-- per effettuare l'esercizio ho escluso i giochi con ID 4, 12, 18
-- per seguire la partecipazione facoltativa della tabella Sales_region nella tabella Sales, ho escluso il Messico (ID 8)

INSERT INTO Sales (Transaction_ID, Toy_ID, Transaction_date, Region_ID) VALUES
(1, 1, '2020-01-15', 1),
(2, 2, '2020-02-25', 2),
(3, 3, '2020-03-05', 3),
(4, 5, '2020-04-15', 4),
(5, 6, '2020-05-25', 5),
(6, 7, '2020-06-15', 6),
(7, 8, '2020-07-25', 7),
(8, 9, '2020-08-15', 9),
(9, 10, '2020-09-25', 10),
(10, 11, '2020-10-05', 1),
(11, 13, '2020-11-15', 2),
(12, 14, '2020-12-25', 3),
(13, 15, '2021-01-05', 4),
(14, 16, '2021-02-15', 5),
(15, 17, '2021-03-25', 6),
(16, 19, '2021-04-05', 7),
(17, 20, '2021-05-15', 9),
(18, 1, '2021-06-25', 10),
(19, 2, '2021-07-05', 1),
(20, 3, '2021-08-15', 2),
(21, 5, '2021-09-25', 3),
(22, 6, '2021-10-05', 4),
(23, 7, '2021-11-15', 5),
(24, 8, '2021-12-25', 6),
(25, 9, '2022-01-05', 7),
(26, 10, '2022-02-15', 9),
(27, 11, '2022-03-25', 10),
(28, 13, '2022-04-05', 1),
(29, 14, '2022-05-15', 2),
(30, 15, '2022-06-25', 3),
(31, 16, '2022-07-05', 4),
(32, 17, '2022-08-15', 5),
(33, 19, '2022-09-25', 6),
(34, 20, '2022-10-05', 7),
(35, 1, '2022-11-15', 9),
(36, 2, '2022-12-25', 10),
(37, 3, '2023-01-05', 1),
(38, 5, '2023-02-15', 2),
(39, 6, '2023-03-25', 3),
(40, 7, '2023-04-05', 4),
(41, 8, '2023-05-15', 5),
(42, 9, '2023-06-25', 6),
(43, 10, '2023-07-05', 7),
(44, 11, '2023-08-15', 9),
(45, 13, '2023-09-25', 10),
(46, 14, '2023-10-05', 1),
(47, 15, '2023-11-15', 2),
(48, 16, '2023-12-25', 3),
(49, 17, '2023-01-15', 4),
(50, 19, '2023-02-25', 5),
(51, 20, '2023-03-05', 6),
(52, 1, '2023-04-15', 7),
(53, 2, '2023-05-25', 9),
(54, 3, '2023-06-15', 10),
(55, 5, '2023-07-25', 1),
(56, 6, '2023-08-15', 2),
(57, 7, '2023-09-25', 3),
(58, 8, '2023-10-05', 4),
(59, 9, '2023-11-15', 5),
(60, 10, '2023-12-25', 6),
(61, 11, '2020-01-05', 7),
(62, 13, '2020-02-15', 9),
(63, 14, '2020-03-25', 10),
(64, 15, '2020-04-05', 1),
(65, 16, '2020-05-15', 2),
(66, 17, '2020-06-25', 3),
(67, 19, '2020-07-05', 4),
(68, 20, '2020-08-15', 5),
(69, 1, '2020-09-25', 6),
(70, 2, '2020-10-05', 7),
(71, 3, '2020-11-15', 9),
(72, 5, '2020-12-25', 10),
(73, 6, '2021-01-15', 1),
(74, 7, '2021-02-25', 2),
(75, 8, '2021-03-05', 3),
(76, 9, '2021-04-15', 4),
(77, 10, '2021-05-25', 5),
(78, 11, '2021-06-15', 6),
(79, 13, '2021-07-25', 7),
(80, 14, '2021-08-15', 9),
(81, 15, '2021-09-25', 10),
(82, 16, '2021-10-05', 1),
(83, 17, '2021-11-15', 2),
(84, 19, '2021-12-25', 3),
(85, 20, '2022-01-05', 4),
(86, 1, '2022-02-15', 5),
(87, 2, '2022-03-25', 6),
(88, 3, '2022-04-05', 7),
(89, 5, '2022-05-15', 9),
(90, 6, '2022-06-25', 10),
(91, 7, '2022-07-05', 1),
(92, 8, '2022-08-15', 2),
(93, 9, '2022-09-25', 3),
(94, 10, '2022-10-05', 4),
(95, 11, '2022-11-15', 5),
(96, 13, '2022-12-25', 6),
(97, 14, '2023-01-05', 7),
(98, 15, '2023-02-15', 9),
(99, 16, '2023-03-25', 10),
(100, 17, '2023-04-05', 1);




-- 1) 	controllare unicità delle PK


SELECT 
    Category_ID, COUNT(Category_ID)
FROM
    Toy_category
GROUP BY Category_ID
HAVING COUNT(Category_ID) > 1

-- controllo su tabella giochi
SELECT 
    Toy_ID, COUNT(Toy_ID)
FROM
    Toy
GROUP BY Toy_ID
HAVING COUNT(Toy_ID) > 1

-- controllo su regioni di vendita
SELECT 
    Region_ID, COUNT(Region_ID)
FROM
    Sales_region
GROUP BY Region_ID
HAVING COUNT(Region_ID) > 1

-- controllo su tabella transazioni
SELECT 
    Transaction_ID, COUNT(Transaction_ID)
FROM
    Sales
GROUP BY Transaction_ID
HAVING COUNT(Transaction_ID) > 1


-- 2) esporre elenco prodotti e fatturato annuale
-- inner join tra tabella giochi e tabella vendite
-- siccome la traccia diceva che ogni transazione riguardava un solo prodotto, non ho inserito un campo quantità
-- quindi ho contato il numero di vendite e sommato il prezzo di vendita per ogni giocattolo/anno
CREATE VIEW Fatturato_annuale_per_prodotto AS
    (SELECT 
        YEAR(S.Transaction_date) AS Ricavi_Annuali,
        T.Toy_name,
        COUNT(S.Transaction_ID) AS Number_of_Sales,
        SUM(T.Toy_price) AS Total_Revenue
    FROM
        Sales S
            JOIN
        Toy T ON S.Toy_ID = T.Toy_ID
    GROUP BY YEAR(S.Transaction_date) , T.Toy_name
    ORDER BY Ricavi_annuali , T.Toy_name)

-- esporre fatturato totale, per stato, per anno
CREATE VIEW Fatturato_per_stato AS
    (SELECT 
        SR.Region_name,
        YEAR(S.Transaction_date) AS Ricavi_Annuali,
        COUNT(S.Transaction_ID) AS Number_of_Sales,
        SUM(T.Toy_price) AS Total_Revenue
    FROM
        Sales S
            JOIN
        Sales_Region SR ON SR.Region_ID = S.Region_ID
            JOIN
        Toy T ON T.Toy_ID = S.Toy_ID
    GROUP BY SR.Region_name , YEAR(S.Transaction_date)
    ORDER BY Ricavi_Annuali , Ricavi_annuali DESC)
   
   -- 4) qual è la categoria di articoli maggiormente richiesta?
   create view Categoria_più_venduta as ( 
   SELECT 
    TC.Category_name,
    COUNT(S.Transaction_ID) AS Number_of_Sales
FROM 
    Sales S
JOIN 
    Toy T ON S.Toy_ID = T.Toy_ID
JOIN 
    Toy_category TC ON T.Category_ID = TC.Category_ID
GROUP BY 
    TC.Category_name
ORDER BY 
    Number_of_Sales DESC
LIMIT 1);

-- 5) Quali sono i prodotti invenduti?
-- primo metodo: 
-- left outer join tra tabella giochi e tabella vendite
-- si ottiene una tabella che avrà tutti i campi completi per i giochi venduti
-- e i campi con valodi a destra nulli per i giochi mai venduti
-- filtro delle sole righe per cui ID giocattoli è uguale a null, in modo da visualizzare solo l'invenduto

   create view Giochi_tristi as ( 
SELECT 
    T.Toy_name
FROM 
    Toy T
LEFT OUTER JOIN 
    Sales S ON T.Toy_ID = S.Toy_ID
WHERE 
    S.Toy_ID IS NULL
    );
    
-- secondo metodo:
CREATE VIEW Giochi_tristi2_la_vendetta AS
    (SELECT 
        T.Toy_name
    FROM
        Toy T
    WHERE
        T.Toy_ID NOT IN (SELECT 
                S.Toy_ID
            FROM
                Sales S));

-- 6) esporre l'elenco dei prodotti con la data di vendita più recente per ognuno
    
CREATE VIEW Ultima_vendita AS
    (SELECT 
        T.Toy_name, MAX(S.Transaction_date) AS Ultima_vendita
    FROM
        Toy T
            JOIN
        Sales S ON T.Toy_ID = S.Toy_ID
    GROUP BY T.Toy_name
    ORDER BY Ultima_vendita);
    
 -- 6/2) prova ultima vendita categoria
    
CREATE VIEW Ultima_vendita_categoria AS
    (SELECT 
        TC.Category_name, MAX(S.Transaction_date) AS Ultima_vendita
    FROM
        Toy_category TC
            JOIN
        Toy T ON TC.Category_ID = T.Category_ID
            JOIN
        Sales S ON T.Toy_ID = S.Toy_ID
    GROUP BY TC.Category_name
    ORDER BY Ultima_vendita);